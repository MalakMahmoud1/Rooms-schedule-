﻿using System;

namespace ConsoleApp17 { 
  public class themain
  {
        
        public static void Main(string[] args)
    {
            #region peeks
            Doctor doctor = new Doctor();
            Patient patient = new Patient();
            Prescription prescription = new Prescription();
            ClinicManagementSystem clinicManagementSystem = new ClinicManagementSystem();
            Appointment appointment = new Appointment();
            doctor.AddDoctor(122, "test", "test");
            #endregion



            while (true) { 
               Console.WriteLine("Welcome to the Clinic Management System!");
               Console.WriteLine("1. Schedule Appointment");
               Console.WriteLine("2. Update Patient Records");
               Console.WriteLine("3. Manage Prescriptions");
               Console.WriteLine("4. Generate Report");
               Console.WriteLine("5. Exit");

            Console.Write("Please select an option: ");
            int option = int.Parse(Console.ReadLine());

            if (option == 1)
            {

                    doctor.DisplayDoctors();
                    appointment.MakeAppointment();
                }
            else if (option == 2)
            {
               patient.Display();
            }
            else if (option == 3)
            {
                prescription.ManagePrescriptions();
            }
            else if (option == 4)
            {
                prescription.GenerateReport();
            }else if(option == 5)
                {
                    Environment.Exit(0);
                }
            else
            {
                Console.WriteLine("Invalid option selected.");}

            }
        }

  }

}

