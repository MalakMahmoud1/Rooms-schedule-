﻿using System;
using System.Collections.Generic;

namespace ConsoleApp17
{
    public class Patient : Person
    {
        #region attr
        public int PatientID { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string MedicalHistory { get; set; }
        #endregion

        public void Display()
        {
            Console.WriteLine("Enter patient ID:");
            int patientID = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter patient name:");
            string name = Console.ReadLine();

            Console.WriteLine("Enter patient age:");
            int age = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter patient medical history:");
            string medicalhistory = Console.ReadLine();

            UpdatePatientRecord(patientID, name, age, medicalhistory);
        }

        public void UpdatePatientRecord(int patientID, string name, int age, string medicalhistory)
        {
            if (patientID == PatientID)
            {
                Name = name;
                Age = age;
                MedicalHistory = medicalhistory;
                Console.WriteLine("Patient record updated successfully.");
                Console.WriteLine($"Patient ID: {PatientID}, Name: {Name}, Age: {Age}, Medical History: {MedicalHistory}");
            }
            else
            {
                Console.WriteLine("Patient not found.");
            }
        }

        public void AddPatientRecord(int patientID, string name, int age, string medicalhistory)
        {
            if (patientID != null)
            {
                PatientID = patientID;
                Name = name;
                Age = age;
                MedicalHistory = medicalhistory;
                Console.WriteLine("Patient record added successfully.");
                Console.WriteLine($"Patient ID: {PatientID}, Name: {Name}, Age: {Age}, Medical History: {MedicalHistory}");
            }
            else
            {
                Console.WriteLine("Invalid ID.");
            }
        }
    }
}
