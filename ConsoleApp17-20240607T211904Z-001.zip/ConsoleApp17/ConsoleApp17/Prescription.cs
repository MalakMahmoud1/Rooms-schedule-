﻿using System;
using System.Data.SqlTypes;
using System.IO;
using System.Numerics;

namespace ConsoleApp17
{
    public class Prescription
    {
        public int PrescriptionID { get; set; }
        public Patient Patient { get; set; }
        public Doctor Doctor { get; set; }
        public string Instructions;
        LinkedList<int> instruction = new LinkedList<int>();

        public void ManagePrescriptions()
        {
            Console.WriteLine("Enter choise : ");
            Console.WriteLine("1. add new one");
            Console.WriteLine("2. display ");
            Console.WriteLine("3. delete ");
            int choise = int.Parse(Console.ReadLine());

            if ( choise ==  1) { 
              Console.Write("Enter ID : ");
              int ID = int.Parse(Console.ReadLine());
              Patient paint = new Patient();
              Doctor DOC = new Doctor();
              Console.Write("Enter The Instructions : ");
              string r = Console.ReadLine();

                Addprescription(ID, paint,DOC, r);
                Console.WriteLine("Added.!");
            }
            else if(choise == 2) {
                Console.WriteLine("What is the id :");
                int id = int.Parse(Console.ReadLine());
                DisplayDetails(id);

            }else if(choise == 3)
            {
                Console.WriteLine("Enter Target ID : ");
                int id = int.Parse(Console.ReadLine());
                del(id);
            }
            else
            {
                Console.WriteLine("Error Choise");
            }



            //methods -->


            void Addprescription(int Prescriptionid, Patient pat, Doctor doc, string instuctions)
            {
                foreach (int i in instruction)
                {
                    if (Prescriptionid == i)
                    {
                        Console.WriteLine($"This ID {Prescriptionid}  is Already Taken ! ");
                    }
                    else
                    {
                        PrescriptionID = Prescriptionid;
                        Patient = pat;
                        Doctor = doc;
                        Instructions = instuctions;
                    }

                }
            }

            void DisplayDetails(int IDD)
            {
                foreach(int i in instruction)
                {
                    if (IDD == i)
                    {
                        Console.WriteLine("Prescription ID: " + PrescriptionID);
                        Console.WriteLine("Patient: " + Patient.Name);
                        Console.WriteLine("Doctor: " + Doctor.Name);
                        Console.WriteLine("Instructions: " + Instructions);
                    }
                    else { Console.WriteLine("Cant Be Found!"); }
                }
                
            }

            void del(int psid)
            {
                foreach (int i in instruction)
                {
                    if (psid == i)
                    {
                        instruction.Remove(i);
                    }
                    else
                    {
                        Console.WriteLine("Cant Find it!!");
                    }

                }

            }
        }


        public void GenerateReport()
        {
            LinkedList<Patient> patients = new LinkedList<Patient>();
            Console.WriteLine("Patient Report:");
            Console.WriteLine("| Patient ID |   Name   | Age | Medical History     |");

            foreach (var patient in patients)
            {
                Console.WriteLine($"| {patient.PatientID} | {patient.Name} | {patient.Age} | {patient.MedicalHistory} |");
            }


        }




    }

}

