﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp17
{
    public class Appointment
    {
        #region attr
        public int AppointmentID { get; set; }
        public Doctor Doctor { get; set; }
        public Patient Patient { get; set; }
        public DateTime AppointmentTime { get; set; }
        Queue<Doctor> DoctorQueue = new Queue<Doctor>();
        #endregion

        public void MakeAppointment()
        {
            Console.WriteLine("Choose a doctor by entering their ID:");
            int id = int.Parse(Console.ReadLine());
            bool found = false;
            foreach (Doctor doc in DoctorQueue)
            {
                if (doc.DoctorID == id)
                {
                    found = true;
                    Console.WriteLine($"Appointment successful!, Doctor id {id} at {DateTime.Now}");
                    break;
                }
            }
            if (!found)
            {
                Console.WriteLine("Doctor not found.");
            }
        }



    }

}
