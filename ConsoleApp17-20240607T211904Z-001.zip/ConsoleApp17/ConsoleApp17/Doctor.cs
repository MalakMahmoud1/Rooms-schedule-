﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace ConsoleApp17
{
    public class Doctor : Person
    {
        #region attr
        public int DoctorID { get; set; }
        public string DoctorName { get; set; }
        public string Specialization { get; set; }
        Queue<Doctor> DoctorQueue = new Queue<Doctor>();
        LinkedList<int> docsIDS = new LinkedList<int>();
        #endregion

        public void AddDoctor(int id, string name, string specialization)
        {
            Doctor doctor = new Doctor();
            doctor.DoctorID = id;
            doctor.DoctorName = name;
            doctor.Specialization = specialization;
            DoctorQueue.Enqueue(doctor);
        }


        public void DisplayDoctors()
        {
            Console.WriteLine("Please Wait.....");
            Thread.Sleep(1000);
            foreach (Doctor doc in DoctorQueue)
            {
                Console.WriteLine($"Doctor ID: {doc.DoctorID}, Name: {doc.DoctorName}, Specialization: {doc.Specialization}");
            }
        }

        public void RemoveDoctor()
        {
            Console.WriteLine("Enter The ID : ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Please Wait.....");
            Thread.Sleep(1800);
            bool found = false;
            foreach (Doctor doc in DoctorQueue)
            {
                if (doc.DoctorID == id)
                {
                    found = true;
                    DoctorQueue.Dequeue();
                }
            }
            if (found)
            {
                docsIDS.Remove(id);
                Console.WriteLine("Doctor removed successfully.");
            }
            else
            {
                Console.WriteLine("Doctor not found.");
            }
        }
    }
}
