﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp17
{
    public abstract class Person
    {

        public string Name { get; set; }
        public int age { get; set; }

    }
}
